//
//  NavigationConfigure.h
//  MobileApp
//
//  Created by Jon Campbell on 1/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NavigationConfigure : NSObject

+ (void)initializeNavigation:(UIWindow*)window;

@end
