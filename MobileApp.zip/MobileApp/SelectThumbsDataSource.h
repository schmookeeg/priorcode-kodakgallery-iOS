//
//  Created by jcampbell on 1/31/12.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>
#import <Three20/Three20.h>


@interface SelectThumbsDataSource : TTThumbsDataSource {

}

@end