//
//  Created by darron on 12/6/11.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>

@interface UIColor (Colors)

+ (NSArray*)titleBarGradientColors;
+ (NSArray*)titleBarGradientLocations;

+ (NSArray*)blackViewGradientColors;

@end