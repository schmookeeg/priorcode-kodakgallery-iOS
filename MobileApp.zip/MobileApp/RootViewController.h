//
//  RootViewController.h
//  MobileApp
//
//  Created by Jon Campbell on 8/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

- (BOOL)showLogo;

@end
