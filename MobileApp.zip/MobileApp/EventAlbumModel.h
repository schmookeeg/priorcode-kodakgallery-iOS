//
//  EventAlbumModel.h
//  MobileApp
//
//  Created by Jon Campbell on 8/2/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AbstractAlbumModel.h"

@interface EventAlbumModel : AbstractAlbumModel

@end
