//
//  Created by darron on 3/6/12.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>


@interface LowResolutionBar : UIView
{
	UILabel *_lowResolutionWarningLabel;
	UILabel *_lowResolutionWarningSubtextLabel;
	UIImageView *_lowResolutionIcon;
}

@end