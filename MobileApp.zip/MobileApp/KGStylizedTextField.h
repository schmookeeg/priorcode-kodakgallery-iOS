//
//  KGStylizedTextField.h
//  MobileApp
//
//  Created by Darron Schall on 8/23/11.
//

#import <UIKit/UIKit.h>

@interface KGStylizedTextField : UITextField

@end
