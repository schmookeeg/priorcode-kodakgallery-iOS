
NSString *const FontStyleNormal = @"normal";
NSString *const FontStyleItalic = @"italic";
NSString *const FontStyleBold = @"bold";
NSString *const FontStyleBoldItalic = @"bolditalic";