//
//  NotificationsViewController.h
//  MobileApp
//
//  Created by Darron Schall on 9/15/11.
//

#import <Three20/Three20.h>
#import "EventNavigationController.h"

@interface NotificationsViewController : TTTableViewController
{
	EventNavigationController *_eventNavController;
}
@end
