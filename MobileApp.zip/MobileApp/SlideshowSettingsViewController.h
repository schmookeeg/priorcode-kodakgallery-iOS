//
//  SlideshowSettingsViewController.h
//  MobileApp
//
//  Created by Darron Schall on 8/25/11.
//

#import <Three20/Three20.h>

@interface SlideshowSettingsViewController : TTTableViewController

@end
