
extern NSString *const FontStyleNormal;
extern NSString *const FontStyleItalic;
extern NSString *const FontStyleBold;
extern NSString *const FontStyleBoldItalic;