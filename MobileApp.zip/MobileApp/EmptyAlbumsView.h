//
//  EmptyAlbumsView.h
//  MobileApp
//
//  Created by Darron Schall on 8/23/11.
//

#import <UIKit/UIKit.h>

@interface EmptyAlbumsView : UIView
{
	IBOutlet UILabel *callToActionLabel;
}

@end
