//
//  SPMRestKitTranslator.h
//  MobileApp
//
//  Created by Darron Schall on 2/28/12.
//  Copyright (c) 2012 Universal Mind, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SPMRestKitTranslator : NSObject

+ (void)initializeRestKitMappings;

@end
