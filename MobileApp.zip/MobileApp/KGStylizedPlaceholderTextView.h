//
//  KGStylizedPlaceholderTextView.h
//  MobileApp
//
//  Created by Darron Schall on 8/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "UIPlaceholderTextView.h"

@interface KGStylizedPlaceholderTextView : UIPlaceholderTextView

@end
