//
//  URLCache.h
//  KGDemo
//
//  Created by mikeb on 5/24/11.
//  Copyright 2011 Kodak Imaging Network. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Three20/Three20.h>


@interface URLCache : TTURLCache
{

}

@end
