//
//  Created by darron on 3/19/12.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>


@interface CharacterLimitWarningBar : UIView
{
	UILabel *_characterLimitWarningLabel;
	UILabel *_characterLimitWarningSubtextLabel;
	UIImageView *_characterLimitIcon;
}

@end