//
//  SettingDelegate.h
//  MobileApp
//
//  Created by Diaspark on 9/19/11.
//  Copyright 2011 Diaspark Inc.. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Three20/Three20.h>


@interface SettingDelegate : TTTableViewDelegate
{

}


@end
